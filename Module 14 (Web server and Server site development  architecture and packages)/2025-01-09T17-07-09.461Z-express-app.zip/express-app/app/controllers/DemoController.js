export const Demo=async (req, res) => {
    res.json({status:"Yes"});
}